export class Reminder{
    constructor(public name: String, public date: Date){}
}
import { Component } from '@angular/core';
import {scheduleJob} from 'node-schedule';
import {FormControl} from '@angular/forms';
import {MatDialog} from '@angular/material/dialog';
import { PopupComponent } from './popup/popup.component';
import {Reminder} from './reminder';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  reminders = [{'name': 'Milk'}, {'name': 'Surf'}]
  reminderForm = new FormControl();
  constructor(public reminderPopup: MatDialog){
    // this.reminderPopup.open(PopupComponent, {
    //   height: '200px',
    //   width: '200px'
    // })
  }
  // ty = scheduleJob("10  * * * * *", ()=> {
  //   console.log("Test")
  //   this.reminderPopup.open(PopupComponent, {
  //     height: '200px',
  //     width: '200px'
  //   })
  // });
  addReminder(){
    scheduleJob(this.reminderForm.value, () => {
      console.log("Reminder")
      this.reminderPopup.open(PopupComponent, {
        height: '200px',
        width: '200px'
      })
    })
    console.log(this.reminderForm.value);
  }
}

//why did no entrycomponent work
